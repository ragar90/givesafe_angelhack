package com.sromku.simple.fb.listeners;

/**
 * On delete request listener
 * 
 * @author koraybalci
 * 
 */
public abstract class OnDeleteListener extends OnActionListener<Void> {
}
