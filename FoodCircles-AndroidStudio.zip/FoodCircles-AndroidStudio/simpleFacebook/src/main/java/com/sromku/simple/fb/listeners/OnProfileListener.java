package com.sromku.simple.fb.listeners;

import com.sromku.simple.fb.entities.Profile;

/**
 * On my profile request listener
 * 
 * @author sromku
 * 
 */
public abstract class OnProfileListener extends OnActionListener<Profile> {
}
