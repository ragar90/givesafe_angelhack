package co.foodcircles.util;


public class Const {
	public static String CONSUMER_KEY = "XmAxvWUI8aFgI7QlliTfCw";
	public static String CONSUMER_SECRET = "ipOQjEZ876e0qWexIOLKOV99TllNPC9LBcMEzCZ4";
	public static String PREFERENCE_NAME = "twitter_oauth";
	public static final String PREF_KEY_SECRET = "oauth_token_secret";
	public static final String PREF_KEY_TOKEN = "oauth_token";
	public static final String CALLBACK_URL = "http://joinfoodcircles.org";
	public static final String IEXTRA_AUTH_URL = "auth_url";
	public static final String IEXTRA_OAUTH_VERIFIER = "oauth_verifier";
	public static final String IEXTRA_OAUTH_TOKEN = "oauth_token";
}
