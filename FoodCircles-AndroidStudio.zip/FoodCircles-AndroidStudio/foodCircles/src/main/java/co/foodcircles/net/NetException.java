package co.foodcircles.net;

@SuppressWarnings("serial")
public class NetException extends Exception
{

}
